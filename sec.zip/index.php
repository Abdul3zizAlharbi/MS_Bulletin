<?php 
include "db.php";
$systemSql = "SELECT * FROM `systemslist` ORDER BY `systemslist`.`systemname` ASC";
$systemSqlresult = $conn->query($systemSql);
//$systemSqlrow = $systemSqlresult->fetch_assoc();
if(@$_POST['system']==null){
@$system= "select system";
}
else{	
@$system= $_POST['system'];
}


//print_r($array);
?>

<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>MS Bulletin</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- DataTables -->
  <script src="bower_components/jquery-1.9.1.js"></script>

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>

<div class ="container">

<div>
<nav class="navbar navbar-default">
<div class="container-fluid">
<a class="navbar-brand" href="#">
</a>
</div>
</div>
</nav>

<div class="jumbotron">
<font size = "5">#Microsoft Security Updates Search Engine</font>
<br>
<font color= "Gray" size = "4">#The idea of this search engine is to dump the installed KB pathes from the target Windows Machine and paste it down. the secript will query all patches for the selected system 
and compair it with provided data. 
 </font>
 <br><br>
 <font color= "Green" size = "4">#command:</font><font  color= "orange" size = "4"> wmic qfe get HotFixId </font>

</div>
<form action ="" method = "POST" class = "form-group" >

<div class="form-group" >

<select  id ="dropdown" class="form-control" name ='system'>
<option selected>select system<option>

<?php 
while($systemSqlrow = $systemSqlresult->fetch_assoc()) { 

	echo "<option>".$systemSqlrow['systemname']."</option>";

} ?>

</select>

</div>


<div>

<div class="row">
<div class="col-md-6">
<textarea placeholder="List of Component KB" class = "form-control" name = "bulletin" rows= "10" cols ="50">
</textarea>
</div>
<div class="col-md-6">
<textarea placeholder="Filter: Service names,runing application,Drives etc..." class="form-control" id="searchInput" value="Type To Filter" rows= "10" cols ="50">
</textarea>
</div>
</div>
<br>
<br>
<div class="form-group" >
<input class="btn btn-warning" type="submit" value = "Submit">
</div>
</div>
</form>
<br>
<br>

<?php 
$sql = "SELECT ComponentKB FROM `bulltinlist` WHERE AffectedProduct = '$system'";
$result = $conn->query($sql);
$countresult = $result->num_rows;


$array1 = array();
 if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$row1 = $row['ComponentKB'];
$array1[]=$row1;	 
    }
}
@$bulletin = $_POST['bulletin'];

$BulletinArray = explode(PHP_EOL,$bulletin);
$trimedArray = preg_replace("/KB/","",$BulletinArray);
$arrayDiff = array_diff($array1,$trimedArray);
$arrayDiff = implode("', '",$arrayDiff);
/* 
Date
Bulltin KB
Severity
Impact
Title
Affected Product
Affected Component
Supersedes
CVEs
 */
if($system == null){}
else {
	
$sqlAllData = "SELECT * FROM `bulltinlist` WHERE ComponentKB in ('$arrayDiff') AND AffectedProduct = '$system' ORDER BY FIELD(`Severity`,'Critical') DESC";
$sqlAllDataresult = $conn->query($sqlAllData);
$countAllDataresult = $sqlAllDataresult->num_rows;
echo "<div class='alert alert-success'> <strong>Selected System: </strong>".$system."</div>";
echo "<div class='alert alert-danger'>"."System has <strong>".$countAllDataresult."</strong> unpatched vulnerabilities out of <strong>".$countresult."</strong> released update</div>";

 if ($result->num_rows > 0) {
echo "<br>";
	 
echo "<table class= 'table table-bordered'>";	
echo "<tr>";
echo "<th>Date</th>";	
echo "<th>Bulletin KB</th>";	
echo "<th>Severity</th>";	
echo "<th>Impact</th>";	
echo "<th>Title</th>";	
echo "<th>Affected Product</th>";	
echo "<th>Affected Component</th>";	
echo "<th>Supersedes</th>";	
echo "<th>CVEs</th>";	
echo "</tr>";	 
echo "<tbody id='fbody'>";
    while($sqlAllDatarow = $sqlAllDataresult->fetch_assoc()) {
echo "<tr><td>";		
echo  $sqlAllDatarow['Date'];
echo "</td><td>";
echo  $sqlAllDatarow['ComponentKB'];
echo "</td><td>";
echo  $sqlAllDatarow['Severity'];
echo "</td><td>";
echo  $sqlAllDatarow['Impact'];
echo "</td><td>";
echo  $sqlAllDatarow['Title'];
echo "</td><td>";
echo  $sqlAllDatarow['AffectedProduct'];
echo "</td><td>";
echo  $sqlAllDatarow['AffectedComponent'];
echo "</td><td>";
echo  $sqlAllDatarow['Supersedes'];
echo "</td><td>";
echo  $sqlAllDatarow['CVEs'];
echo "</td></tr>";

    }
echo "</tbody>";
echo "</table>";	
}

}
?>
</div>
</div>
<script>
document.getElementById('dropdown').value= "<?php echo $system;?>";
</script>
<script>
$("#searchInput").keyup(function() {
  // Split the current value of the filter textbox
  var data = this.value.split("\n");
  // Get the table rows
  var rows = $("#fbody").find("tr");
  if (this.value == "") {
    rows.show();
    return;
  }

  // Hide all the rows initially
  rows.hide();

  // Filter the rows; check each term in data
  rows.filter(function(i, v) {
      for (var d = 0; d < data.length; ++d) {
        if ($(this).is(":contains('" + data[d] + "')")) {
          return true;
        }
      }
      return false;
    })
    // Show the rows that match.
    .show();
}).focus(function() { // style the filter box
  this.value = "";
  $(this).css({
    "color": "black"
  });
  $(this).unbind('focus');
}).css({
  "color": "#C0C0C0"
});

// make contains case insensitive globally
// (if you prefer, create a new Contains or containsCI function)
$.expr[":"].contains = $.expr.createPseudo(function(arg) {
  return function(elem) {
    return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
  };
});

</script>
</html>